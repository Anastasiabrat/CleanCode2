import cleancode2ev_anastasiabratkiv.Administrador;
import cleancode2ev_anastasiabratkiv.ExcepcionCupoParticipantesLLeno;
import cleancode2ev_anastasiabratkiv.Participantes;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AdministadorTest {

    public AdministadorTest() {
    }

    @BeforeAll
    public static void setUpClass() {
        System.out.println("Este método se ejecuta para configurar una vez antes de que se ejecuten todos los tests.");
    }

    @AfterAll
    public static void tearDownClass() {
        System.out.println(
                "Este método se ejecuta para limpiar una vez después de que se hayan ejecutado todos los tests.");
    }

    @BeforeEach
    public void setUp() {
        System.out.println("Este método se ejecuta para configurar antes de cada test.");
    }

    @AfterEach
    public void tearDown() {
        System.out.println("Este método se ejecuta para limpiar después de cada test.");
    }


    @Test // Verificar colorDorsal segun sexo.
    public void testColorDorsal() throws ExcepcionCupoParticipantesLLeno {
        Participantes participante = Administrador.registrarParticipante("Test",
                Participantes.Marca2000, 'M', "azul");
        assertEquals("azul", participante.getColorDorsal());

        participante = Administrador.registrarParticipante("Test", 
                Participantes.Marca2000, 'F', "amarillo");
        assertEquals("amarillo", participante.getColorDorsal());
    }


    @Test
    public void testUniqueMarcaParticipantes() throws ExcepcionCupoParticipantesLLeno {
        Participantes participante1 = Administrador.registrarParticipante("Part1",
                Participantes.Marca2001, 'M',"azul");
        Participantes participante2 = Administrador.registrarParticipante("Part2",
                Participantes.Marca2000, 'F',"amarillo");

        assertNotEquals(participante1.getMarca(), participante2.getMarca());

    }

    @Test
    public void testRegistrarParticipanteIncrementsDorsalNumber() throws ExcepcionCupoParticipantesLLeno {
        int initialDorsalNumber = Participantes.getNumDorsal();
        Administrador.registrarParticipante("Test", Participantes.Marca2000, 'M', "azul");
        assertEquals(initialDorsalNumber + 1, Participantes.getNumDorsal());
    }


    
}
