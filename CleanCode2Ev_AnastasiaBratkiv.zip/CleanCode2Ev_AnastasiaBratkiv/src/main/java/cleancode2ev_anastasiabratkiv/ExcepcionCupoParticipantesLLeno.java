package cleancode2ev_anastasiabratkiv;

    public class ExcepcionCupoParticipantesLLeno extends RuntimeException {
        public ExcepcionCupoParticipantesLLeno(String message) {
            super(message);
        }
    }
