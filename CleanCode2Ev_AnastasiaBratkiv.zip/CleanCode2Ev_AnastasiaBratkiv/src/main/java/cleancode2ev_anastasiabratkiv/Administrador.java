package cleancode2ev_anastasiabratkiv;

import static cleancode2ev_anastasiabratkiv.Participantes.*;

import java.util.ArrayList;
import java.util.List;

public class Administrador {

    private static List<Participantes> listaParticipantes = new ArrayList<>();

    public static void main(String[] args) {
        try {
            registrarParticipante("Juan", Marca2001, 'M', "azul");
            registrarParticipante("María", Marca2000, 'F', "amarillo");
            registrarParticipante("Pedro", Marca2002, 'M', "azul");
            mostrarInformacionParticipantes();
        } catch (ExcepcionCupoParticipantesLLeno e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public static Participantes registrarParticipante(String nombre, int marca,
            char sexo, String colorDorsal) throws ExcepcionCupoParticipantesLLeno {
        if (numDorsal < numMaxParticipantes) {
            numDorsal++;
            Participantes participante = new Participantes(nombre, marca, sexo, colorDorsal);
            listaParticipantes.add(participante);
            System.out.println("Registrando a " + nombre + " con dorsal " + numDorsal
                    + " y marca " + obtenerNombreMarca(marca)
                    + ". Sexo: " + sexo + " - colorDorsal: " + colorDorsal);
            return participante;
        } else {
            throw new ExcepcionCupoParticipantesLLeno("No hay cupo para más participantes.");
        }
    }

    public static String obtenerNombreMarca(int codigoMarca) {
        switch (codigoMarca) {
            case Marca2000:
                return "Marca 2000";
            case Marca2001:
                return "Marca 2001";
            case Marca2002:
                return "Marca 2002";
            default:
                return "Marca Desconocida";
        }
    }

    private static void mostrarInformacionParticipantes() {
        System.out.println("\nInformación de Participantes:");
        for (Participantes participante : listaParticipantes) {
            System.out.println("Dorsal " + participante.getNumDorsal() + ": "
                    + obtenerNombreMarca(participante.getMarca())
                    + " - Nombre: " + participante.getNombre());
        }
    }

    private static void mostrarInformacionParticipantesCopia() {
        // Hacer una copia de la lista
        List<Participantes> copiaListaParticipantes = new ArrayList<>(listaParticipantes);

        System.out.println("\nInformaciÃ³n de Participantes:");
        for (Participantes participante : copiaListaParticipantes) {
            System.out.println("Dorsal " + participante.getNumDorsal() + ": "
                    + obtenerNombreMarca(participante.getMarca()) 
                    + " - Nombre: " + participante.getNombre());
        }
    }
}
