package cleancode2ev_anastasiabratkiv;

public class Participantes {
    
    public static final int Marca2000 = 1;
    public static final int Marca2001 = 2;
    public static final int Marca2002 = 3;
    public static final int numMaxParticipantes = 10;
    public static int numDorsal = 0;   
    private String nombre;
    private int marca;
    private char sexo;
    private String colorDorsal;
    
    
    public Participantes(String nombre, int marca, char sexo, String colorDorsal) {
        this.nombre = nombre;
        this.marca = marca;
        this.sexo = sexo;
        this.colorDorsal = colorDorsal;
        numDorsal++;
    }

    // Getters and setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getMarca() {
        return marca;
    }

    public void setMarca(int marca) {
        this.marca = marca;
    }

    public char getSexo() {
        return sexo;
    }

    public void setSexo(char sexo) {
        this.sexo = sexo;
    }

    public String getColorDorsal() {
        return colorDorsal;
    }

    public void setColorDorsal(String colorDorsal) {
        this.colorDorsal = colorDorsal;
    }
    
    public static int getNumDorsal() {
        return numDorsal;
    }
}
